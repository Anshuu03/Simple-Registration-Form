var express=require("express")
var bodyParser=require("body-parser")
var mongoose=require("mongoose")

const app=express()


app.get("/",(req,res) => {
    res.send("Server Connection is Successsful")
  }).listen(1200);

console.log("Listening on port 1200")